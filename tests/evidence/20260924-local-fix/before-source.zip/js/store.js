/*
 * Creator Scout 独立首页原型 · 状态模型（store）
 *
 * 职责：
 *   - 当前空间、每空间 viewState（会话位置）与未发送草稿（按 spaceId+conversationId 隔离）
 *   - localStorage 持久化；损坏/非法数据回退安全默认值，不混空间
 *   - 空间切换：切换序号守卫（旧空间的延迟响应不能覆盖新空间）、
 *     处理中锁定重复选择、失败保留原空间与输入并支持重试
 *   - 退出登录：仅结束本地演示登录状态，不删除任何空间数据
 *
 * 本文件只做状态与规则，不做 DOM 渲染；渲染见 ui.js。
 */
(function (global) {
  'use strict';

  var Fixtures = global.Fixtures;
  var BLANK = Fixtures.BLANK_DRAFT_ID;
  var STORAGE_KEY = 'creator_scout_home_v1';

  function spaceById(id) {
    for (var i = 0; i < Fixtures.spaces.length; i++) {
      if (Fixtures.spaces[i].id === id) return Fixtures.spaces[i];
    }
    return null;
  }

  function conversationOfSpace(space, convId) {
    if (!space || !convId) return null;
    for (var i = 0; i < space.conversations.length; i++) {
      if (space.conversations[i].id === convId) return space.conversations[i];
    }
    return null;
  }

  function draftKey(spaceId, conversationId) {
    return spaceId + '::' + (conversationId == null ? BLANK : conversationId);
  }

  function sleep(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  // 默认切换传输：模拟加载目标空间数据。刻意保持简短，不加人为长延时；
  // 测试通过 __setTransport 注入延迟 / 失败 / 乱序响应。
  function defaultTransport(targetSpaceId, seq) {
    return sleep(120).then(function () {
      return { spaceId: targetSpaceId, seq: seq };
    });
  }

  function createStore(options) {
    options = options || {};
    var storage = options.storage || (function () {
      try { return global.localStorage; } catch (e) { return null; }
    })();
    var storageKey = options.storageKey || STORAGE_KEY;
    var transport = defaultTransport;

    // ---------------- 持久化（带净化的安全加载） ----------------
    function sanitize(data) {
      if (!data || typeof data !== 'object' || data.version !== 1) return null;
      var currentSpaceId = spaceById(data.currentSpaceId) ? data.currentSpaceId : Fixtures.defaultSpaceId;
      var viewStates = {};
      var drafts = {};
      Fixtures.spaces.forEach(function (space) {
        var vs = data.viewStates && data.viewStates[space.id];
        var convId = vs && vs.activeConversationId;
        viewStates[space.id] = {
          activeConversationId: conversationOfSpace(space, convId) ? convId : null
        };
        space.conversations.concat([{ id: BLANK }]).forEach(function (conv) {
          var key = draftKey(space.id, conv.id);
          var val = data.drafts && data.drafts[key];
          if (typeof val === 'string') drafts[key] = val;
        });
      });
      return {
        version: 1,
        currentSpaceId: currentSpaceId,
        signedOut: !!data.signedOut,
        viewStates: viewStates,
        drafts: drafts
      };
    }

    function loadOrDefault() {
      if (!storage) return defaultState();
      try {
        var raw = storage.getItem(storageKey);
        if (!raw) return defaultState();
        return sanitize(JSON.parse(raw)) || defaultState();
      } catch (e) {
        // 损坏的存储：安全默认值（默认团队空间、无草稿），不混入空间数据
        return defaultState();
      }
    }

    function defaultState() {
      var viewStates = {};
      var drafts = {};
      Fixtures.spaces.forEach(function (space) {
        viewStates[space.id] = { activeConversationId: null };
      });
      return {
        version: 1,
        currentSpaceId: Fixtures.defaultSpaceId,
        signedOut: false,
        viewStates: viewStates,
        drafts: drafts
      };
    }

    var state = loadOrDefault();

    var persistTimer = null;
    var listeners = [];

    function emitChange() {
      listeners.slice().forEach(function (fn) { try { fn(); } catch (e) { /* 单个监听器异常不阻断其他 */ } });
    }

    function persist() {
      if (!storage) return;
      var raw = JSON.stringify({
        version: 1,
        currentSpaceId: state.currentSpaceId,
        signedOut: state.signedOut,
        viewStates: state.viewStates,
        drafts: state.drafts
      });
      storage.setItem(storageKey, raw); // 配额/安全模式等异常向上抛出，由调用方处理
    }

    function schedulePersist() {
      if (!storage) return;
      if (persistTimer) clearTimeout(persistTimer);
      persistTimer = setTimeout(function () {
        persistTimer = null;
        try { persist(); } catch (e) { /* 草稿输入期的静默失败：切换/刷新时 flushDrafts 仍会暴露错误 */ }
      }, 200);
    }

    function flushDrafts() {
      if (persistTimer) { clearTimeout(persistTimer); persistTimer = null; }
      return new Promise(function (resolve, reject) {
        if (!storage) return resolve();
        try { persist(); resolve(); } catch (e) { reject(e); }
      });
    }

    // ---------------- 空间切换（序号守卫 + 锁定 + 失败保留） ----------------
    var switchSeq = 0;
    var switching = null; // { to, seq }

    /**
     * 请求切换到目标空间。
     * - 目标为当前空间：不改变任何数据（选择当前项不清空首页）。
     * - 新请求会取代进行中的请求（序号递增）；旧请求的延迟响应/失败按 stale 忽略，
     *   不能覆盖新空间视图。产品 UI 在切换中会锁定入口，不会主动制造并发。
     * - 切换前先落盘当前空间草稿；落盘失败则阻止切换并保留输入。
     * 返回 Promise<{ ok, stale?, reason?, target? }>。
     */
    function switchSpace(targetSpaceId) {
      if (!spaceById(targetSpaceId)) {
        return Promise.resolve({ ok: false, reason: 'unknown-space', target: targetSpaceId });
      }
      if (targetSpaceId === state.currentSpaceId && !switching) {
        return Promise.resolve({ ok: true, noop: true, target: targetSpaceId });
      }
      var seq = ++switchSeq;
      switching = { to: targetSpaceId, seq: seq };
      emitChange(); // 呈现“切换中”反馈并锁定重复操作

      return flushDrafts()
        .then(function () { return transport(targetSpaceId, seq); })
        .then(function (res) {
          if (seq !== switchSeq) return { ok: false, stale: true, reason: 'stale', target: targetSpaceId };
          if (!res || res.spaceId !== targetSpaceId) {
            return { ok: false, reason: 'mismatch', target: targetSpaceId };
          }
          state.currentSpaceId = targetSpaceId;
          try { persist(); } catch (e) { /* 已切换成功；存储失败不回滚空间，后续输入继续重试落盘 */ }
          return { ok: true, target: targetSpaceId };
        })
        .catch(function (err) {
          if (seq !== switchSeq) return { ok: false, stale: true, reason: 'stale', target: targetSpaceId };
          return { ok: false, reason: 'error', error: err, target: targetSpaceId };
        })
        .then(function (result) {
          if (switching && switching.seq === seq) switching = null;
          if (!result.stale) emitChange();
          return result;
        });
    }

    // ---------------- 对外 API ----------------
    var store = {
      // 数据访问
      getAccount: function () { return Fixtures.account; },
      getTeam: function () { return Fixtures.team; },
      getMembershipRole: function () { return 'creator'; },
      getSpaces: function () { return Fixtures.spaces; },
      getSpace: spaceById,
      getPlatforms: function () { return Fixtures.platforms; },
      getState: function () { return state; },
      getCurrentSpace: function () { return spaceById(state.currentSpaceId); },

      // 会话位置（按空间隔离）
      getActiveConversationId: function (spaceId) {
        var vs = state.viewStates[spaceId || state.currentSpaceId];
        return vs ? vs.activeConversationId : null;
      },
      openConversation: function (conversationId) {
        var space = spaceById(state.currentSpaceId);
        if (!conversationOfSpace(space, conversationId)) return;
        state.viewStates[space.id].activeConversationId = conversationId;
        try { persist(); } catch (e) { schedulePersist(); }
        emitChange();
      },
      openBlankSession: function () {
        state.viewStates[state.currentSpaceId].activeConversationId = null;
        try { persist(); } catch (e) { schedulePersist(); }
        emitChange();
      },

      // 未发送草稿（按空间 + 会话隔离；空白会话共用每空间独立的 BLANK 键）
      getDraft: function (spaceId, conversationId) {
        return state.drafts[draftKey(spaceId, conversationId)] || '';
      },
      setDraft: function (spaceId, conversationId, text) {
        var key = draftKey(spaceId, conversationId);
        if (text === '' || text == null) delete state.drafts[key];
        else state.drafts[key] = String(text);
        schedulePersist();
      },
      flushDrafts: flushDrafts,

      // 空间切换
      switchSpace: switchSpace,
      isSwitching: function () { return !!switching; },
      getSwitchingTo: function () { return switching ? switching.to : null; },

      // 退出登录（仅本地演示状态）
      confirmLogout: function () {
        state.signedOut = true;
        try { persist(); } catch (e) { /* 内存态已退出；存储失败不阻断演示退出 */ }
        emitChange();
      },
      reenterDemo: function () {
        state.signedOut = false;
        try { persist(); } catch (e) { /* 同上 */ }
        emitChange();
      },

      // 订阅
      onChange: function (fn) { listeners.push(fn); return function () { listeners = listeners.filter(function (x) { return x !== fn; }); }; },

      // ---- 测试注入口（仅 tests 使用；产品代码不得调用） ----
      __setTransport: function (fn) { transport = fn || defaultTransport; },
      __resetTransport: function () { transport = defaultTransport; },
      __getSwitchSeq: function () { return switchSeq; },
      __clearSwitchingLockForTest: function () { switching = null; }
    };
    return store;
  }

  global.Store = { create: createStore, draftKey: draftKey };
})(window);
