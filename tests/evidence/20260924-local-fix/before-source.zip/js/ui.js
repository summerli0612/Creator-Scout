/*
 * Creator Scout 独立首页原型 · 渲染层（ui）
 * 只负责根据 store / fixture 数据生成 DOM 与轻量反馈，不持有业务状态。
 * 浮窗四态的显隐与顺序由 computePopoverModel 纯函数计算，主界面与测试共用。
 */
(function (global) {
  'use strict';

  var Fixtures = global.Fixtures;
  var BLANK = Fixtures.BLANK_DRAFT_ID;

  var assetBase = 'assets/';
  function icon(name) { return assetBase + name; }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  var ROLE_LABELS = { creator: '创建者', admin: '管理员', member: '普通成员' };

  /* ------------------------------------------------------------------
   * 账户浮窗模型（四态规则，对齐 account-popover.md 矩阵）
   * 入参 fixtureLike：{ account, team, membershipRole, currentSpaceType }
   *   - team 为 null 表示无团队：空间区整区不存在（不留占位），
   *     空间功能为 用量与计费 → 业务邮箱 → 开启团队协作，无切换按钮。
   *   - 已有团队：团队空间按角色显示身份；创建者/管理员显示团队管理；
   *     普通成员不显示团队管理；个人空间不显示团队管理，也不显示开启团队协作。
   * ------------------------------------------------------------------ */
  function computePopoverModel(fixtureLike) {
    var account = fixtureLike.account;
    var team = fixtureLike.team || null;
    var role = fixtureLike.membershipRole || null;
    var currentSpaceType = fixtureLike.currentSpaceType || 'personal';
    var hasTeam = !!team;
    var inTeam = hasTeam && currentSpaceType === 'team';

    var spaceSection = null;
    if (hasTeam) {
      if (inTeam) {
        spaceSection = {
          kind: 'team',
          name: team.name,
          initial: team.avatarInitial,
          typeLabel: '团队空间',
          roleLabel: ROLE_LABELS[role] || '',
          canSwitch: true
        };
      } else {
        spaceSection = {
          kind: 'personal',
          name: '个人空间',
          typeLabel: null,
          roleLabel: null,
          canSwitch: true
        };
      }
    }

    var spaceMenu = [{ id: 'usage', label: '用量与计费', icon: 'icon-usage.svg' }];
    if (inTeam && (role === 'creator' || role === 'admin')) {
      spaceMenu.push({ id: 'team-manage', label: '团队管理', icon: 'icon-team.svg' });
    }
    spaceMenu.push({ id: 'mail', label: '业务邮箱', icon: 'icon-mail.svg' });
    if (!hasTeam) {
      spaceMenu.push({ id: 'start-team', label: '开启团队协作', icon: 'icon-team.svg' });
    }

    return {
      account: account,
      hasTeam: hasTeam,
      inTeam: inTeam,
      canManageTeam: inTeam && (role === 'creator' || role === 'admin'),
      spaceSection: spaceSection,
      spaceMenu: spaceMenu,
      accountMenu: [
        { id: 'notifications', label: '通知', icon: 'icon-notify.svg', badge: account.unreadCount },
        { id: 'settings', label: '个人设置', icon: 'icon-settings.svg' }
      ]
    };
  }

  /* ------------------------------------------------------------------
   * 账户浮窗 DOM（默认账户菜单视图）
   * ------------------------------------------------------------------ */
  function popoverAccountHTML(model, opts) {
    opts = opts || {};
    var switching = !!opts.switching;
    var h = '';
    h += '<div class="pop-account">';
    h += '<div class="pop-avatar">' + esc(model.account.avatarInitial) + '</div>';
    h += '<div class="pop-account-text"><div class="pop-name">' + esc(model.account.name) + '</div>' +
      '<div class="pop-email en">' + esc(model.account.email) + '</div></div>';
    h += '</div>';

    if (model.spaceSection) {
      var s = model.spaceSection;
      h += '<div class="pop-space"><div class="space-row">';
      if (s.kind === 'team') {
        h += '<div class="space-avatar">' + esc(s.initial) + '</div>';
        h += '<div class="space-meta"><div class="space-name space-name--en">' + esc(s.name) + '</div>';
        h += '<div class="space-tags"><span class="tag-space">' + esc(s.typeLabel) + '</span>' +
          '<span class="space-role">' + esc(s.roleLabel) + '</span></div></div>';
      } else {
        h += '<img class="space-icon" src="' + icon('icon-personal-space.svg') + '" alt="">';
        h += '<div class="space-meta"><div class="space-name">' + esc(s.name) + '</div></div>';
      }
      // 直接切换：点击即切换到另一空间（账号最多一个个人空间 + 一个团队空间，二者互切）
      h += '<button type="button" class="switch-btn" data-action="switch-space" aria-label="切换空间"' +
        (switching ? ' disabled' : '') + '><img src="' + icon('icon-switch-arrows.svg') + '" alt=""></button>';
      h += '<span class="switch-hint' + (switching ? ' is-busy' : '') + '" aria-hidden="true">' +
        (switching ? '切换中…' : '切换空间') + '</span>';
      h += '</div></div>';
    }

    h += '<div class="pop-divider" role="separator"></div>';
    h += '<div class="pop-menu" role="menu">';
    model.spaceMenu.forEach(function (item) {
      h += '<button type="button" class="pop-menu-item" role="menuitem" data-action="unavailable" ' +
        'data-name="' + esc(item.label) + '"' + (switching ? ' disabled' : '') + '>' +
        '<img src="' + icon(item.icon) + '" alt=""><span>' + esc(item.label) + '</span></button>';
    });
    h += '</div>';

    h += '<div class="pop-divider" role="separator"></div>';
    h += '<div class="pop-menu" role="menu">';
    model.accountMenu.forEach(function (item) {
      var badge = item.badge ? '<span class="badge-unread en">' + esc(item.badge) + '</span>' : '';
      h += '<button type="button" class="pop-menu-item" role="menuitem" data-action="unavailable" ' +
        'data-name="' + esc(item.label) + '"' + (switching ? ' disabled' : '') + '>' +
        '<img src="' + icon(item.icon) + '" alt=""><span>' + esc(item.label) + '</span>' + badge + '</button>';
    });
    h += '</div>';

    h += '<div class="pop-divider" role="separator"></div>';
    h += '<div class="pop-menu" role="menu">';
    h += '<button type="button" class="pop-menu-item pop-menu-item--logout" role="menuitem" data-action="logout"' +
      (switching ? ' disabled' : '') + '>' +
      '<img src="' + icon('icon-logout.svg') + '" alt=""><span>退出登录</span></button>';
    h += '</div>';
    return h;
  }

  /* ------------------------------------------------------------------
   * 侧栏
   * ------------------------------------------------------------------ */
  function renderSidebar(store) {
    var account = store.getAccount();
    var space = store.getCurrentSpace();
    var activeConvId = store.getActiveConversationId(space.id);
    var h = '';

    // AI Agent 分区
    h += '<div class="side-section side-section--agents"><div class="side-label">AI Agent</div>';
    store.getPlatforms().forEach(function (p) {
      var selected = p.id === 'instagram' && activeConvId === null;
      h += '<button type="button" class="nav-item' + (selected ? ' is-selected' : '') +
        '" data-platform="' + esc(p.id) + '" data-available="' + (p.available ? '1' : '0') + '">' +
        '<img class="nav-icon" src="' + icon('icon-' + p.id + '.svg') + '" alt=""><span class="nav-label">' +
        esc(p.label) + '</span></button>';
    });
    h += '</div>';

    // 项目分区
    h += '<div class="side-section side-section--projects"><div class="side-label">项目</div>';
    space.projects.forEach(function (proj) {
      h += '<button type="button" class="nav-item" data-project-id="' + esc(proj.id) + '">' +
        '<img class="nav-icon" src="' + icon('icon-folder.svg') + '" alt=""><span class="nav-label">' +
        esc(proj.name) + '</span></button>';
    });
    h += '</div>';

    // 最近分区
    h += '<div class="side-section side-section--recents"><div class="side-label">最近</div>';
    space.conversations.forEach(function (conv) {
      var selected = conv.id === activeConvId;
      h += '<button type="button" class="nav-item nav-item--recent' + (selected ? ' is-selected' : '') +
        '" data-conv-id="' + esc(conv.id) + '">' +
        '<img class="nav-icon" src="' + icon('icon-chat.svg') + '" alt="">' +
        '<span class="nav-text"><span class="nav-title">' + esc(conv.displayTitle) + '</span>' +
        '<span class="nav-sub">项目助手</span></span></button>';
    });
    h += '</div>';

    var scrollRoot = document.getElementById('sidebar-scroll');
    scrollRoot.innerHTML = h;
    renderAccountEntry(store, account, space);
  }

  function renderAccountEntry(store, account, space) {
    var entry = document.getElementById('sidebar-account');
    entry.innerHTML =
      '<button type="button" class="account-entry" id="account-entry" aria-haspopup="dialog" aria-expanded="false">' +
      '<span class="entry-avatar">' + esc(account.avatarInitial) + '</span>' +
      '<span class="entry-text"><span class="entry-name">' + esc(account.name) + '</span>' +
      '<span class="entry-space">' + esc(space.name) + '</span></span>' +
      '<span class="entry-chevron">' + ICONS.chevronUp + '</span></button>';
  }

  /* ------------------------------------------------------------------
   * 顶栏
   * ------------------------------------------------------------------ */
  function renderTopbar(store) {
    var space = store.getCurrentSpace();
    var activeConvId = store.getActiveConversationId(space.id);
    var topbar = document.getElementById('topbar');
    var h = '<img class="top-icon" src="' + icon('icon-instagram.svg') + '" alt="">';
    if (!activeConvId) {
      h += '<span class="top-title">Instagram 达人营销</span>';
      h += '<span class="top-meta">新会话</span>';
    } else {
      var conv = space.conversations.filter(function (c) { return c.id === activeConvId; })[0];
      var proj = space.projects.filter(function (p) { return p.id === conv.projectId; })[0];
      h += '<span class="top-title">Instagram 达人营销</span>';
      h += '<span class="top-sub">' + esc(conv.displayTitle) + '</span>';
      h += '<span class="top-meta">关联项目：' + esc(proj ? proj.name : '') + '</span>';
      h += '<button type="button" class="btn-enter-project" data-action="unavailable" data-name="项目工作区">' +
        '<img src="' + icon('icon-folder.svg') + '" alt="">进入项目  →</button>';
    }
    topbar.innerHTML = h;
  }

  /* ------------------------------------------------------------------
   * 会话列（空白新会话 / 历史会话）
   * ------------------------------------------------------------------ */
  function composerHTML(spaceId, convId, placeholder, variant) {
    return '<div class="composer composer--' + variant + '" data-space-id="' + esc(spaceId) +
      '" data-conv-id="' + esc(convId == null ? BLANK : convId) + '">' +
      '<textarea placeholder="' + esc(placeholder) + '" aria-label="需求描述输入框" rows="2"></textarea>' +
      '<div class="composer-actions">' +
      '<button type="button" class="btn-ghost" data-action="unavailable" data-name="添加附件">＋  添加附件</button>' +
      '<button type="button" class="btn-ghost btn-link" data-action="unavailable" data-name="添加链接">↗  添加链接</button>' +
      '<button type="button" class="btn-send" data-action="send">发送  →</button>' +
      '</div></div>';
  }

  function renderConversation(store) {
    var space = store.getCurrentSpace();
    var activeConvId = store.getActiveConversationId(space.id);
    var root = document.getElementById('conversation-col');
    var h = '';

    if (!activeConvId) {
      // 默认空白会话（306:74）
      h += '<div class="blank-session">';
      h += '<img class="blank-mark" src="' + icon('mark-instagram.svg') + '" alt="">';
      h += '<div class="blank-title">开始一个 Instagram 达人营销项目</div>';
      h += '<div class="blank-sub">描述你的品牌、产品，以及想寻找什么样的达人。\nAI 会据此整理项目画像与 Agent 任务草稿。</div>';
      h += composerHTML(space.id, null, '描述品牌、产品和目标达人……', 'blank');
      h += '<div class="blank-hints-label">可以从这些信息开始描述</div>';
      h += '<div class="blank-hints">';
      h += '<div class="blank-hint"><div class="hint-title">品牌与产品</div><div class="hint-sub">说明你在推广什么</div></div>';
      h += '<div class="hint-divider" aria-hidden="true"></div>';
      h += '<div class="blank-hint"><div class="hint-title">市场与达人</div><div class="hint-sub">说明地区和达人方向</div></div>';
      h += '<div class="hint-divider" aria-hidden="true"></div>';
      h += '<div class="blank-hint"><div class="hint-title">本轮目标</div><div class="hint-sub">补充数量与筛选条件</div></div>';
      h += '</div>';
      h += '<div class="blank-note">首次发送后才会创建会话，并显示在左侧“最近”</div>';
      h += '</div>';
    } else {
      // 历史会话：只读历史 + 可编辑输入框（不重放消息）
      var conv = space.conversations.filter(function (c) { return c.id === activeConvId; })[0];
      var proj = space.projects.filter(function (p) { return p.id === conv.projectId; })[0];
      h += '<div class="chat-view">';
      h += '<div class="chat-scroll">';
      h += '<div class="chat-date">' + esc(conv.dateLabel) + '</div>';
      conv.messages.forEach(function (m) {
        if (m.role === 'user') {
          h += '<div class="msg-block"><div class="msg-sender msg-sender--user">你</div>' +
            '<div class="msg-bubble--user">' + esc(m.text) + '</div></div>';
        } else {
          h += '<div class="msg-block"><div class="msg-sender">Instagram  Agent</div>' +
            '<div class="msg-card--agent"><div class="agent-title">' + esc(m.title) + '</div>' +
            '<div class="agent-body">' + esc(m.body) + '</div>';
          if (m.summary && m.summary.length) {
            h += '<div class="agent-summary">';
            m.summary.forEach(function (row) {
              h += '<div class="agent-summary-row"><span class="row-label">' + esc(row.label) + '</span>' +
                '<span class="row-value">' + esc(row.value) + '</span></div>';
            });
            h += '</div>';
          }
          h += '</div></div>';
        }
      });
      h += '</div>';
      h += composerHTML(space.id, conv.id, '继续补充或修改需求……', 'chat');
      h += '<div class="chat-footnote">已关联 ' + esc(proj ? proj.name : '') + ' · 会话继续可用</div>';
      h += '</div>';
    }
    root.innerHTML = h;

    // 恢复未发送草稿（按空间 + 会话隔离）
    var composer = root.querySelector('.composer');
    if (composer) {
      var textarea = composer.querySelector('textarea');
      var draft = store.getDraft(composer.dataset.spaceId, composer.dataset.convId);
      if (draft) textarea.value = draft;
      updateSendState(composer);
      textarea.addEventListener('input', function () {
        store.setDraft(composer.dataset.spaceId, composer.dataset.convId, textarea.value);
        updateSendState(composer);
      });
    }
  }

  function updateSendState(composer) {
    var textarea = composer.querySelector('textarea');
    var send = composer.querySelector('.btn-send');
    var ready = textarea.value.trim().length > 0;
    send.classList.toggle('is-ready', ready);
    send.setAttribute('aria-disabled', ready ? 'false' : 'true');
  }

  /* ------------------------------------------------------------------
   * 轻提示 Toast
   * ------------------------------------------------------------------ */
  function showToast(message, opts) {
    opts = opts || {};
    var root = document.getElementById('toast-root');
    var el = document.createElement('div');
    el.className = 'toast';
    el.setAttribute('role', 'status');
    var actionHTML = opts.actionLabel
      ? '<button type="button" class="toast-action">' + esc(opts.actionLabel) + '</button>'
      : '';
    el.innerHTML = '<span>' + esc(message) + '</span>' + actionHTML;
    root.appendChild(el);
    var closed = false;
    function close() {
      if (closed) return;
      closed = true;
      if (timer) clearTimeout(timer);
      if (el.parentNode) el.parentNode.removeChild(el);
      if (opts.onClose) opts.onClose();
    }
    var timer = setTimeout(close, opts.duration || (opts.actionLabel ? 8000 : 3500));
    if (opts.actionLabel) {
      el.querySelector('.toast-action').addEventListener('click', function () {
        close();
        if (opts.onAction) opts.onAction();
      });
    }
    return { close: close };
  }

  /* ------------------------------------------------------------------
   * 二次确认弹窗（焦点圈定 + Esc 取消）
   * ------------------------------------------------------------------ */
  function showConfirmModal(opts) {
    var root = document.getElementById('modal-root');
    root.innerHTML =
      '<div class="modal-overlay">' +
      '<div class="modal" role="dialog" aria-modal="true" aria-label="' + esc(opts.title) + '">' +
      '<div class="modal-title">' + esc(opts.title) + '</div>' +
      '<div class="modal-body">' + esc(opts.body) + '</div>' +
      '<div class="modal-actions">' +
      '<button type="button" class="btn btn-ghost-modal" data-modal="cancel">' + esc(opts.cancelLabel || '取消') + '</button>' +
      '<button type="button" class="btn btn-primary" data-modal="confirm">' + esc(opts.confirmLabel || '确定') + '</button>' +
      '</div></div></div>';
    var overlay = root.querySelector('.modal-overlay');
    var cancelBtn = root.querySelector('[data-modal="cancel"]');
    var confirmBtn = root.querySelector('[data-modal="confirm"]');

    function close() { root.innerHTML = ''; document.removeEventListener('keydown', onKeydown, true); }
    function onCancel() { close(); if (opts.onCancel) opts.onCancel(); }
    function onConfirm() { close(); if (opts.onConfirm) opts.onConfirm(); }
    function onKeydown(e) {
      if (e.key === 'Escape') { e.stopPropagation(); onCancel(); return; }
      if (e.key === 'Tab') {
        // 焦点圈定在弹窗内
        if (document.activeElement === confirmBtn && !e.shiftKey) { e.preventDefault(); cancelBtn.focus(); }
        else if (document.activeElement === cancelBtn && e.shiftKey) { e.preventDefault(); confirmBtn.focus(); }
      }
    }
    cancelBtn.addEventListener('click', onCancel);
    confirmBtn.addEventListener('click', onConfirm);
    document.addEventListener('keydown', onKeydown, true);
    cancelBtn.focus();
    return { close: close };
  }

  /* ------------------------------------------------------------------
   * 内联小图标（非品牌资产，仅交互指示符）
   * ------------------------------------------------------------------ */
  var ICONS = {
    chevronUp: '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M2.5 8L6 4.5L9.5 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };

  global.UI = {
    setAssetBase: function (base) { assetBase = base; },
    esc: esc,
    ICONS: ICONS,
    computePopoverModel: computePopoverModel,
    popoverAccountHTML: popoverAccountHTML,
    renderSidebar: renderSidebar,
    renderTopbar: renderTopbar,
    renderConversation: renderConversation,
    updateSendState: updateSendState,
    showToast: showToast,
    showConfirmModal: showConfirmModal
  };
})(window);
