/*
 * Creator Scout 独立首页原型 · 应用装配（app）
 * 负责：事件接线、浮窗开关、空间切换调用、退出登录确认。
 * 交互规则要点：
 *   - 浮窗：点击账户入口开关；点击外部 / Esc 关闭；切换期间锁定重复操作。
 *   - 空间切换：点击浮窗切换按钮直接切换到另一空间（账号最多一个个人空间 +
 *     一个团队空间，二者互切，无需选择列表）；切换中锁定并显示「切换中…」；
 *     成功后关浮窗；失败保留原空间与输入并提供重试。
 *   - 未接入功能：统一轻提示，保持当前页面，不伪造成功结果。
 *   - 退出登录：先二次确认；取消保持原状态；确认仅结束本地演示登录。
 */
(function (global) {
  'use strict';

  var Store = global.Store;
  var UI = global.UI;
  var store = Store.create();

  var appState = {
    popoverOpen: false
  };

  // ---------------- 渲染 ----------------
  function renderAll() {
    var state = store.getState();
    var app = document.getElementById('app');
    var signedOut = document.getElementById('signed-out');
    if (state.signedOut) {
      app.hidden = true;
      signedOut.hidden = false;
      appState.popoverOpen = false;
      document.getElementById('popover-root').innerHTML = '';
      return;
    }
    app.hidden = false;
    signedOut.hidden = true;
    UI.renderSidebar(store);
    UI.renderTopbar(store);
    UI.renderConversation(store);
  }

  function renderPopover() {
    var root = document.getElementById('popover-root');
    var entry = document.getElementById('account-entry');
    if (entry) entry.setAttribute('aria-expanded', appState.popoverOpen ? 'true' : 'false');
    if (!appState.popoverOpen) { root.innerHTML = ''; return; }

    var el = document.createElement('div');
    el.className = 'account-popover';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-label', '账户菜单');
    var model = UI.computePopoverModel({
      account: store.getAccount(),
      team: store.getTeam(),
      membershipRole: store.getMembershipRole(),
      currentSpaceType: store.getCurrentSpace().type
    });
    el.innerHTML = UI.popoverAccountHTML(model, { switching: store.isSwitching() });
    root.innerHTML = '';
    root.appendChild(el);
  }

  function openPopover() {
    appState.popoverOpen = true;
    renderPopover();
  }

  function closePopover() {
    appState.popoverOpen = false;
    renderPopover();
  }

  // ---------------- 空间切换 ----------------
  function handleSwitchResult(result, targetSpaceId) {
    if (result.ok) { closePopover(); return; }
    if (result.stale) return; // 旧请求被更新的切换取代，不做任何界面变化
    // 失败：保留原空间与输入，提供重试
    UI.showToast('切换空间失败，已保留当前空间与输入。', {
      actionLabel: '重试',
      onAction: function () { requestSwitch(targetSpaceId); }
    });
  }

  function requestSwitch(targetSpaceId) {
    if (store.isSwitching()) return;
    store.switchSpace(targetSpaceId).then(function (result) {
      handleSwitchResult(result, targetSpaceId);
    });
  }

  // 另一空间 ID：账号最多一个个人空间 + 一个团队空间，切换按钮即在二者间互切
  function otherSpaceId() {
    var current = store.getState().currentSpaceId;
    var spaces = store.getSpaces();
    for (var i = 0; i < spaces.length; i++) {
      if (spaces[i].id !== current) return spaces[i].id;
    }
    return null;
  }

  // ---------------- 事件 ----------------
  function onSidebarClick(e) {
    var nav = e.target.closest('.nav-item');
    if (!nav) return;
    if (nav.dataset.platform) {
      if (nav.dataset.available === '1') {
        store.openBlankSession(); // Instagram：当前空间打开新的空白会话视图
      } else {
        UI.showToast('该功能暂未开放。');
      }
      return;
    }
    if (nav.dataset.projectId) {
      UI.showToast('项目工作区暂未开放。'); // 本轮不合并 V9，不跳转示例项目
      return;
    }
    if (nav.dataset.convId) {
      store.openConversation(nav.dataset.convId);
      return;
    }
  }

  function onAccountEntryClick(e) {
    var entry = e.target.closest('.account-entry');
    if (!entry) return;
    e.stopPropagation();
    if (store.isSwitching()) return; // 切换中锁定
    if (appState.popoverOpen) closePopover();
    else openPopover();
  }

  function onPopoverClick(e) {
    var btn = e.target.closest('button');
    if (!btn) return;
    if (btn.dataset.action === 'switch-space') {
      // 直接切换：无需选择列表
      if (store.isSwitching()) return;
      var target = otherSpaceId();
      if (target) requestSwitch(target);
      return;
    }
    if (btn.dataset.action === 'logout') {
      closePopover();
      UI.showConfirmModal({
        title: '退出登录',
        body: '确定要退出登录吗？\n退出仅结束本地演示登录状态，不会删除任何已保存的数据。',
        confirmLabel: '退出登录',
        cancelLabel: '取消',
        onConfirm: function () { store.confirmLogout(); }
        // 取消：不改变任何状态，保持原空间与输入
      });
      return;
    }
    if (btn.dataset.action === 'unavailable') {
      var name = btn.dataset.name || '该功能';
      closePopover(); // 菜单动作已受理（展示提示），按菜单惯例收起浮窗
      if (name === '项目工作区') UI.showToast('项目工作区暂未开放。');
      else UI.showToast('该功能暂未开放。');
      return;
    }
  }

  function onConversationClick(e) {
    var btn = e.target.closest('button');
    if (!btn) return;
    if (btn.dataset.action === 'send') {
      var composer = btn.closest('.composer');
      var textarea = composer.querySelector('textarea');
      if (!textarea.value.trim()) return; // 空内容不可发送（保持灰色禁用语义）
      // 本轮不接真实发送 / 材料解析 / AI 回复：诚实提示并保留输入，不伪造成功结果
      UI.showToast('发送功能暂未开放，你的输入已保留。');
      return;
    }
    if (btn.dataset.action === 'unavailable') {
      UI.showToast('该功能暂未开放。');
    }
  }

  function onDocumentClick(e) {
    if (!appState.popoverOpen) return;
    if (e.target.closest('.account-popover')) return;
    if (e.target.closest('#account-entry') || e.target.closest('.account-entry')) return;
    closePopover();
  }

  function onDocumentKeydown(e) {
    if (e.key === 'Escape' && appState.popoverOpen) {
      e.stopPropagation();
      closePopover();
    }
  }

  // ---------------- 启动 ----------------
  function init() {
    document.getElementById('sidebar-scroll').addEventListener('click', onSidebarClick);
    document.getElementById('sidebar-account').addEventListener('click', onAccountEntryClick);
    document.getElementById('popover-root').addEventListener('click', onPopoverClick);
    document.getElementById('conversation-col').addEventListener('click', onConversationClick);
    document.addEventListener('click', onDocumentClick);
    document.addEventListener('keydown', onDocumentKeydown);

    document.getElementById('reenter-btn').addEventListener('click', function () {
      store.reenterDemo();
    });

    // 刷新 / 离开前落盘未发送输入（localStorage 同步写入）
    global.addEventListener('beforeunload', function () { store.flushDrafts(); });
    global.addEventListener('pagehide', function () { store.flushDrafts(); });

    store.onChange(function () {
      renderAll();
      if (appState.popoverOpen) renderPopover();
    });

    renderAll();
  }

  init();

  // 测试注入口：仅供 tests/verify.py 等自动化脚本注入延迟 / 失败传输使用，
  // 产品界面不提供任何调试开关。
  global.__creatorScoutStore = store;
})(window);
