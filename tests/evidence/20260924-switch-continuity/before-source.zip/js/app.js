/*
 * Creator Scout 独立首页原型 · 应用装配（app）
 * 负责：事件接线、浮窗开关、空间切换调用、退出登录确认。
 * 交互规则要点：
 *   - 浮窗：点击账户入口开关；点击外部 / Esc 关闭；切换期间锁定重复操作。
 *   - 空间切换：点击浮窗切换按钮直接切换到另一空间（账号最多一个个人空间 +
 *     一个团队空间，二者互切，无需选择列表）；切换中锁定并显示「切换中…」；
 *     成功后关浮窗；失败保留原空间与输入并提供重试。
 *   - 未接入功能：统一轻提示，保持当前页面，不伪造成功结果。
 *   - 退出登录：先二次确认；取消保持原状态；确认仅结束本地演示登录。
 */
(function (global) {
  'use strict';

  var Store = global.Store;
  var UI = global.UI;
  var store = Store.create();
  var disposeSwitchHint = null;

  function clearSwitchHint() {
    if (disposeSwitchHint) disposeSwitchHint();
    disposeSwitchHint = null;
  }


  var appState = {
    popoverOpen: false,
    popoverFocusKey: null
  };

  function focusAccountEntry() {
    var entry = document.getElementById('account-entry');
    if (entry) entry.focus({ preventScroll: true });
  }

  function popoverButtons(el) {
    return Array.prototype.slice.call(el.querySelectorAll('button:not(:disabled)'));
  }

  // 保存的是可重新解析的目标，不把已被 innerHTML 替换的 DOM 引用当成返回焦点。
  function capturePageFocus() {
    var el = document.activeElement;
    if (!el || !document.getElementById('app').contains(el)) return null;
    if (el.id === 'account-entry') return { kind: 'account' };
    if (el.matches('.nav-item')) return { kind: 'nav', platform: el.dataset.platform, conv: el.dataset.convId, project: el.dataset.projectId };
    if (el.matches('.composer textarea')) return { kind: 'input', start: el.selectionStart, end: el.selectionEnd,
      draft: el.closest('.composer').dataset.convId, space: el.closest('.composer').dataset.spaceId };
    if (el.matches('.btn-enter-project')) return { kind: 'enter-project' };
    if (el.closest('.composer') && el.matches('button')) return { kind: 'composer-button', action: el.dataset.action, name: el.dataset.name };
    return null;
  }

  function restorePageFocus(saved) {
    if (!saved) return;
    var target = null;
    if (saved.kind === 'account') { focusAccountEntry(); return; }
    if (saved.kind === 'nav') {
      target = Array.prototype.slice.call(document.querySelectorAll('.nav-item')).filter(function (el) {
        return el.dataset.platform === saved.platform && el.dataset.convId === saved.conv && el.dataset.projectId === saved.project;
      })[0];
    } else if (saved.kind === 'input') target = document.querySelector('.composer textarea');
    else if (saved.kind === 'enter-project') target = document.querySelector('.btn-enter-project');
    else if (saved.kind === 'composer-button') {
      target = Array.prototype.slice.call(document.querySelectorAll('.composer button:not(:disabled)')).filter(function (el) {
        return el.dataset.action === saved.action && el.dataset.name === saved.name;
      })[0] || document.querySelector('.composer textarea');
    }
    if (target) {
      target.focus({ preventScroll: true });
      if (saved.kind === 'input' && target.closest('.composer').dataset.convId === saved.draft && target.closest('.composer').dataset.spaceId === saved.space) {
        target.setSelectionRange(saved.start, saved.end);
      }
    }
  }

  // ---------------- 渲染 ----------------
  function renderAll() {
    var previousFocus = capturePageFocus();
    var state = store.getState();
    var app = document.getElementById('app');
    var signedOut = document.getElementById('signed-out');
    if (state.signedOut) {
      clearSwitchHint();
      app.hidden = true;
      signedOut.hidden = false;
      appState.popoverOpen = false;
      document.getElementById('popover-root').innerHTML = '';
      return;
    }
    app.hidden = false;
    signedOut.hidden = true;
    UI.renderSidebar(store);
    UI.renderTopbar(store);
    UI.renderConversation(store);
    restorePageFocus(previousFocus);
  }

  function renderPopover() {
    clearSwitchHint();
    var root = document.getElementById('popover-root');
    var old = root.querySelector('.account-popover');
    var hadFocus = old && old.contains(document.activeElement);
    var oldScroll = old ? old.scrollTop : 0;
    if (hadFocus && document.activeElement.matches('button')) {
      appState.popoverFocusKey = { action: document.activeElement.dataset.action, name: document.activeElement.dataset.name };
    }
    var entry = document.getElementById('account-entry');
    if (entry) entry.setAttribute('aria-expanded', appState.popoverOpen ? 'true' : 'false');
    if (!appState.popoverOpen) { root.innerHTML = ''; return; }

    var el = document.createElement('div');
    el.className = 'account-popover';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-label', '账户菜单');
    el.tabIndex = -1; // 切换中按钮禁用时，焦点仍有一个有效停留位置。
    el.setAttribute('aria-busy', store.isSwitching() ? 'true' : 'false');
    var model = UI.computePopoverModel({
      account: store.getAccount(),
      team: store.getTeam(),
      membershipRole: store.getMembershipRole(),
      currentSpaceType: store.getCurrentSpace().type
    });
    el.innerHTML = UI.popoverAccountHTML(model, { switching: store.isSwitching(), hintId: 'space-switch-hint' });
    root.innerHTML = '';
    root.appendChild(el);
    disposeSwitchHint = UI.attachSwitchHint(el, root);
    if (hadFocus) {
      var buttons = popoverButtons(el);
      var key = appState.popoverFocusKey;
      var target = key && buttons.filter(function (btn) { return btn.dataset.action === key.action && btn.dataset.name === key.name; })[0];
      (target || buttons[0] || el).focus({ preventScroll: true });
      el.scrollTop = oldScroll;
    }
  }

  function openPopover(fromKeyboard) {
    appState.popoverOpen = true;
    appState.popoverFocusKey = null;
    renderPopover();
    if (fromKeyboard) {
      var el = document.querySelector('.account-popover');
      (popoverButtons(el)[0] || el).focus();
    }
  }

  function closePopover(restoreFocus) {
    appState.popoverOpen = false;
    renderPopover();
    if (restoreFocus) focusAccountEntry();
  }

  // ---------------- 空间切换 ----------------
  function handleSwitchResult(result, targetSpaceId) {
    if (result.ok) {
      var root = document.getElementById('popover-root');
      closePopover(root.contains(document.activeElement));
      return;
    }
    if (result.stale) return; // 旧请求被更新的切换取代，不做任何界面变化
    // 失败：保留原空间与输入，提供重试
    UI.showToast('切换空间失败，已保留当前空间与输入。', {
      actionLabel: '重试',
      onAction: function () { focusAccountEntry(); requestSwitch(targetSpaceId); }
    });
  }

  function requestSwitch(targetSpaceId) {
    if (store.isSwitching()) return;
    store.switchSpace(targetSpaceId).then(function (result) {
      handleSwitchResult(result, targetSpaceId);
    });
  }

  // 另一空间 ID：账号最多一个个人空间 + 一个团队空间，切换按钮即在二者间互切
  function otherSpaceId() {
    var current = store.getState().currentSpaceId;
    var spaces = store.getSpaces();
    for (var i = 0; i < spaces.length; i++) {
      if (spaces[i].id !== current) return spaces[i].id;
    }
    return null;
  }

  // ---------------- 事件 ----------------
  function onSidebarClick(e) {
    if (store.isSwitching()) return;
    var nav = e.target.closest('.nav-item');
    if (!nav) return;
    if (nav.dataset.platform) {
      if (nav.dataset.available === '1') {
        store.openBlankSession(); // Instagram：当前空间打开新的空白会话视图
      } else {
        UI.showToast('该功能暂未开放。');
      }
      return;
    }
    if (nav.dataset.projectId) {
      UI.showToast('项目工作区暂未开放。'); // 本轮不合并 V9，不跳转示例项目
      return;
    }
    if (nav.dataset.convId) {
      store.openConversation(nav.dataset.convId);
      return;
    }
  }

  function onAccountEntryClick(e) {
    var entry = e.target.closest('.account-entry');
    if (!entry) return;
    e.stopPropagation();
    if (store.isSwitching()) return; // 切换中锁定
    if (appState.popoverOpen) closePopover(e.detail === 0);
    else openPopover(e.detail === 0);
  }

  function onPopoverClick(e) {
    var btn = e.target.closest('button');
    if (!btn) return;
    if (btn.dataset.action === 'switch-space') {
      // 直接切换：无需选择列表
      if (store.isSwitching()) return;
      var target = otherSpaceId();
      if (target) requestSwitch(target);
      return;
    }
    if (btn.dataset.action === 'logout') {
      closePopover();
      UI.showConfirmModal({
        title: '退出登录',
        body: '确定要退出登录吗？\n退出仅结束本地演示登录状态，不会删除任何已保存的数据。',
        confirmLabel: '退出登录',
        cancelLabel: '取消',
        onConfirm: function () {
          store.confirmLogout();
          document.getElementById('reenter-btn').focus();
        },
        onCancel: focusAccountEntry // 动态查找仍存在的入口；保留原空间与输入
      });
      return;
    }
    if (btn.dataset.action === 'unavailable') {
      var name = btn.dataset.name || '该功能';
      closePopover(true); // 菜单动作会删除按钮，焦点回到仍存在的账户入口
      if (name === '项目工作区') UI.showToast('项目工作区暂未开放。');
      else UI.showToast('该功能暂未开放。');
      return;
    }
  }

  function onConversationClick(e) {
    var btn = e.target.closest('button');
    if (!btn) return;
    if (btn.dataset.action === 'send') {
      var composer = btn.closest('.composer');
      var textarea = composer.querySelector('textarea');
      if (!textarea.value.trim()) return; // 空内容不可发送（保持灰色禁用语义）
      // 本轮不接真实发送 / 材料解析 / AI 回复：诚实提示并保留输入，不伪造成功结果
      UI.showToast('发送功能暂未开放，你的输入已保留。');
      return;
    }
    if (btn.dataset.action === 'unavailable') {
      UI.showToast(btn.dataset.name === '项目工作区' ? '项目工作区暂未开放。' : '该功能暂未开放。');
    }
  }

  function onDocumentClick(e) {
    if (!appState.popoverOpen) return;
    if (e.target.closest('.account-popover')) return;
    if (e.target.closest('#account-entry') || e.target.closest('.account-entry')) return;
    closePopover();
  }

  function onDocumentKeydown(e) {
    if (!appState.popoverOpen) return;
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      closePopover(true);
      return;
    }
    if (e.key === 'Tab') {
      var el = document.querySelector('.account-popover');
      var active = document.activeElement;
      if (!el || (!el.contains(active) && active.id !== 'account-entry')) return;
      var buttons = popoverButtons(el);
      if (!buttons.length) { e.preventDefault(); el.focus(); return; }
      var first = buttons[0], last = buttons[buttons.length - 1];
      if (!el.contains(active) || active === el) {
        e.preventDefault(); (e.shiftKey ? last : first).focus();
      } else if (e.shiftKey && active === first) {
        e.preventDefault(); last.focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault(); first.focus();
      }
    }
  }

  // ---------------- 启动 ----------------
  function init() {
    document.getElementById('sidebar-scroll').addEventListener('click', onSidebarClick);
    document.getElementById('sidebar-account').addEventListener('click', onAccountEntryClick);
    document.getElementById('popover-root').addEventListener('click', onPopoverClick);
    document.getElementById('conversation-col').addEventListener('click', onConversationClick);
    document.getElementById('topbar').addEventListener('click', onConversationClick);
    document.addEventListener('click', onDocumentClick);
    document.addEventListener('keydown', onDocumentKeydown);

    document.getElementById('reenter-btn').addEventListener('click', function () {
      store.reenterDemo();
      focusAccountEntry();
    });

    // 刷新 / 离开前落盘未发送输入（localStorage 同步写入）
    global.addEventListener('beforeunload', function () { store.flushDrafts().catch(function () {}); });
    global.addEventListener('pagehide', function () { store.flushDrafts().catch(function () {}); });

    store.onChange(function () {
      renderAll();
      if (appState.popoverOpen) renderPopover();
    });

    renderAll();
  }

  init();

  // 测试注入口：仅供 tests/verify.py 等自动化脚本注入延迟 / 失败传输使用，
  // 产品界面不提供任何调试开关。
  global.__creatorScoutStore = store;
})(window);
