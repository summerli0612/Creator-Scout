/*
 * Creator Scout 独立首页原型 · 状态模型（store）
 *
 * 职责：
 *   - 当前空间、每空间 viewState（会话位置）与未发送草稿（按 spaceId+conversationId 隔离）
 *   - localStorage 持久化；损坏/非法数据回退安全默认值，不混空间
 *   - 空间切换：切换序号守卫（旧空间的延迟响应不能覆盖新空间）、
 *     处理中锁定重复选择、失败保留原空间与输入并支持重试
 *   - 退出登录：仅结束本地演示登录状态，不删除任何空间数据
 *
 * 本文件只做状态与规则，不做 DOM 渲染；渲染见 ui.js。
 */
(function (global) {
  'use strict';

  var Fixtures = global.Fixtures;
  var BLANK = Fixtures.BLANK_DRAFT_ID;
  var STORAGE_KEY = 'creator_scout_home_v1';

  // 兼容原 v1 的 __blank__；新草稿只增加内部标识，不生成正式会话/项目。
  function isBlankDraftId(id) {
    return id === BLANK || (typeof id === 'string' && /^__draft__[a-z0-9-]{1,80}$/i.test(id));
  }

  function spaceById(id) {
    for (var i = 0; i < Fixtures.spaces.length; i++) {
      if (Fixtures.spaces[i].id === id) return Fixtures.spaces[i];
    }
    return null;
  }

  function conversationOfSpace(space, convId) {
    if (!space || !convId) return null;
    for (var i = 0; i < space.conversations.length; i++) {
      if (space.conversations[i].id === convId) return space.conversations[i];
    }
    return null;
  }

  function draftKey(spaceId, conversationId) {
    return spaceId + '::' + (conversationId == null ? BLANK : conversationId);
  }

  function sleep(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  // 默认切换传输：模拟加载目标空间数据。刻意保持简短，不加人为长延时；
  // 测试通过 __setTransport 注入延迟 / 失败 / 乱序响应。
  function defaultTransport(targetSpaceId, seq) {
    return sleep(120).then(function () {
      return { spaceId: targetSpaceId, seq: seq };
    });
  }

  function createStore(options) {
    options = options || {};
    var storage = options.storage || (function () {
      try { return global.localStorage; } catch (e) { return null; }
    })();
    var storageKey = options.storageKey || STORAGE_KEY;
    var transport = defaultTransport;

    // ---------------- 持久化（带净化的安全加载） ----------------
    function sanitize(data) {
      if (!data || typeof data !== 'object' || data.version !== 1) return null;
      var currentSpaceId = spaceById(data.currentSpaceId) ? data.currentSpaceId : Fixtures.defaultSpaceId;
      var viewStates = {};
      var drafts = {};
      Fixtures.spaces.forEach(function (space) {
        var vs = data.viewStates && data.viewStates[space.id];
        var convId = vs && vs.activeConversationId;
        var blankIds = [BLANK];
        if (vs && Array.isArray(vs.blankDraftIds)) {
          vs.blankDraftIds.forEach(function (id) {
            if (isBlankDraftId(id) && blankIds.indexOf(id) === -1) blankIds.push(id);
          });
        }
        viewStates[space.id] = {
          activeConversationId: conversationOfSpace(space, convId) ? convId : null,
          activeBlankDraftId: vs && blankIds.indexOf(vs.activeBlankDraftId) !== -1 ? vs.activeBlankDraftId : BLANK,
          blankDraftIds: blankIds
        };
        space.conversations.concat(blankIds.map(function (id) { return { id: id }; })).forEach(function (conv) {
          var key = draftKey(space.id, conv.id);
          var val = data.drafts && data.drafts[key];
          if (typeof val === 'string') drafts[key] = val;
        });
      });
      return {
        version: 1,
        currentSpaceId: currentSpaceId,
        signedOut: !!data.signedOut,
        viewStates: viewStates,
        drafts: drafts
      };
    }

    function loadOrDefault() {
      if (!storage) return defaultState();
      try {
        var raw = storage.getItem(storageKey);
        if (!raw) return defaultState();
        return sanitize(JSON.parse(raw)) || defaultState();
      } catch (e) {
        // 损坏的存储：安全默认值（默认团队空间、无草稿），不混入空间数据
        return defaultState();
      }
    }

    function defaultState() {
      var viewStates = {};
      var drafts = {};
      Fixtures.spaces.forEach(function (space) {
        viewStates[space.id] = { activeConversationId: null, activeBlankDraftId: BLANK, blankDraftIds: [BLANK] };
      });
      return {
        version: 1,
        currentSpaceId: Fixtures.defaultSpaceId,
        signedOut: false,
        viewStates: viewStates,
        drafts: drafts
      };
    }

    var state = loadOrDefault();

    function newBlankDraftId(spaceId) {
      var ids = state.viewStates[spaceId].blankDraftIds;
      var id;
      do {
        var suffix = global.crypto && typeof global.crypto.randomUUID === 'function'
          ? global.crypto.randomUUID()
          : Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
        id = '__draft__' + suffix;
      } while (ids.indexOf(id) !== -1);
      return id;
    }

    function resolveDraftId(spaceId, id) {
      var space = spaceById(spaceId);
      var vs = state.viewStates[spaceId];
      if (!space || !vs) return null;
      if (id == null) id = vs.activeBlankDraftId;
      return conversationOfSpace(space, id) || vs.blankDraftIds.indexOf(id) !== -1 ? id : null;
    }

    var persistTimer = null;
    var listeners = [];

    function emitChange() {
      listeners.slice().forEach(function (fn) { try { fn(); } catch (e) { /* 单个监听器异常不阻断其他 */ } });
    }

    function persist() {
      if (!storage) return;
      var raw = JSON.stringify({
        version: 1,
        currentSpaceId: state.currentSpaceId,
        signedOut: state.signedOut,
        viewStates: state.viewStates,
        drafts: state.drafts
      });
      storage.setItem(storageKey, raw); // 配额/安全模式等异常向上抛出，由调用方处理
    }

    function schedulePersist() {
      if (!storage) return;
      if (persistTimer) clearTimeout(persistTimer);
      persistTimer = setTimeout(function () {
        persistTimer = null;
        try { persist(); } catch (e) { /* 草稿输入期的静默失败：切换/刷新时 flushDrafts 仍会暴露错误 */ }
      }, 200);
    }

    function flushDrafts() {
      if (persistTimer) { clearTimeout(persistTimer); persistTimer = null; }
      return new Promise(function (resolve, reject) {
        if (!storage) return resolve();
        try { persist(); resolve(); } catch (e) { reject(e); }
      });
    }

    // ---------------- 空间切换（序号守卫 + 锁定 + 失败保留） ----------------
    var switchSeq = 0;
    var switching = null; // { to, seq }

    /**
     * 请求切换到目标空间。
     * - 目标为当前空间：不改变任何数据（选择当前项不清空首页）。
     * - 新请求会取代进行中的请求（序号递增）；旧请求的延迟响应/失败按 stale 忽略，
     *   不能覆盖新空间视图。产品 UI 在切换中会锁定入口，不会主动制造并发。
     * - 切换前先落盘当前空间草稿；落盘失败则阻止切换并保留输入。
     * 返回 Promise<{ ok, stale?, reason?, target? }>。
     */
    function switchSpace(targetSpaceId) {
      if (!spaceById(targetSpaceId)) {
        return Promise.resolve({ ok: false, reason: 'unknown-space', target: targetSpaceId });
      }
      if (targetSpaceId === state.currentSpaceId && !switching) {
        return Promise.resolve({ ok: true, noop: true, target: targetSpaceId });
      }
      var seq = ++switchSeq;
      switching = { to: targetSpaceId, seq: seq };
      emitChange(); // 呈现“切换中”反馈并锁定重复操作

      return flushDrafts()
        .then(function () { return transport(targetSpaceId, seq); })
        .then(function (res) {
          if (seq !== switchSeq) return { ok: false, stale: true, reason: 'stale', target: targetSpaceId };
          if (!res || res.spaceId !== targetSpaceId) {
            return { ok: false, reason: 'mismatch', target: targetSpaceId };
          }
          state.currentSpaceId = targetSpaceId;
          try { persist(); } catch (e) { /* 已切换成功；存储失败不回滚空间，后续输入继续重试落盘 */ }
          return { ok: true, target: targetSpaceId };
        })
        .catch(function (err) {
          if (seq !== switchSeq) return { ok: false, stale: true, reason: 'stale', target: targetSpaceId };
          return { ok: false, reason: 'error', error: err, target: targetSpaceId };
        })
        .then(function (result) {
          if (switching && switching.seq === seq) switching = null;
          if (!result.stale) emitChange();
          return result;
        });
    }

    // ---------------- 对外 API ----------------
    var store = {
      // 数据访问
      getAccount: function () { return Fixtures.account; },
      getTeam: function () { return Fixtures.team; },
      getMembershipRole: function () { return 'creator'; },
      getSpaces: function () { return Fixtures.spaces; },
      getSpace: spaceById,
      getPlatforms: function () { return Fixtures.platforms; },
      getState: function () { return state; },
      getCurrentSpace: function () { return spaceById(state.currentSpaceId); },

      // 会话位置（按空间隔离）
      getActiveConversationId: function (spaceId) {
        var vs = state.viewStates[spaceId || state.currentSpaceId];
        return vs ? vs.activeConversationId : null;
      },
      getActiveBlankDraftId: function (spaceId) {
        var vs = state.viewStates[spaceId || state.currentSpaceId];
        return vs ? vs.activeBlankDraftId : null;
      },
      getActiveDraftId: function (spaceId) {
        var vs = state.viewStates[spaceId || state.currentSpaceId];
        return vs ? (vs.activeConversationId || vs.activeBlankDraftId) : null;
      },
      openConversation: function (conversationId) {
        if (switching || state.signedOut) return;
        var space = spaceById(state.currentSpaceId);
        if (!conversationOfSpace(space, conversationId)) return;
        state.viewStates[space.id].activeConversationId = conversationId;
        try { persist(); } catch (e) { schedulePersist(); }
        emitChange();
      },
      openBlankSession: function () {
        if (switching || state.signedOut) return;
        var vs = state.viewStates[state.currentSpaceId];
        var id = newBlankDraftId(state.currentSpaceId);
        vs.activeConversationId = null;
        vs.activeBlankDraftId = id;
        vs.blankDraftIds.push(id);
        // 只切换当前输入的内部 ID，不删除此前草稿或其他空间/会话的内容。
        try { persist(); } catch (e) { schedulePersist(); }
        emitChange();
        return id;
      },

      // 未发送草稿按空间 + 独立草稿/会话 ID 隔离。null 表示该空间当前空白草稿；
      // 显式 __blank__ 保留原 v1 含义，旧数据以增量字段兼容，不清空或改写历史草稿。
      getDraft: function (spaceId, conversationId) {
        var id = resolveDraftId(spaceId, conversationId);
        return id ? (state.drafts[draftKey(spaceId, id)] || '') : '';
      },
      setDraft: function (spaceId, conversationId, text) {
        var id = resolveDraftId(spaceId, conversationId);
        if (!id) return false;
        var key = draftKey(spaceId, id);
        if (text === '' || text == null) delete state.drafts[key];
        else state.drafts[key] = String(text);
        schedulePersist();
        return true;
      },
      flushDrafts: flushDrafts,

      // 空间切换
      switchSpace: switchSpace,
      isSwitching: function () { return !!switching; },
      getSwitchingTo: function () { return switching ? switching.to : null; },

      // 退出登录（仅本地演示状态）
      confirmLogout: function () {
        state.signedOut = true;
        try { persist(); } catch (e) { /* 内存态已退出；存储失败不阻断演示退出 */ }
        emitChange();
      },
      reenterDemo: function () {
        state.signedOut = false;
        try { persist(); } catch (e) { /* 同上 */ }
        emitChange();
      },

      // 订阅
      onChange: function (fn) { listeners.push(fn); return function () { listeners = listeners.filter(function (x) { return x !== fn; }); }; },

      // ---- 测试注入口（仅 tests 使用；产品代码不得调用） ----
      __setTransport: function (fn) { transport = fn || defaultTransport; },
      __resetTransport: function () { transport = defaultTransport; },
      __getSwitchSeq: function () { return switchSeq; },
      __clearSwitchingLockForTest: function () { switching = null; }
    };
    return store;
  }

  global.Store = { create: createStore, draftKey: draftKey };
})(window);
