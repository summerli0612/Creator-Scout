# -*- coding: utf-8 -*-
"""
Creator Scout 独立首页原型 · Playwright 端到端验证
用法:  python tests/verify.py   （在 creator-scout-home 目录下运行，或任意位置）
产出:  screenshots/ 下的运行截图 + 控制台测试结果
依赖:  playwright（本机 Python 环境已安装，含 chromium）
"""
import sys
import pathlib
import traceback

# Windows 控制台默认 GBK，输出含 ✅/❌ 等字符时强制 UTF-8
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

ROOT = pathlib.Path(__file__).resolve().parent.parent
SHOTS = ROOT / "screenshots"
SHOTS.mkdir(exist_ok=True)

from playwright.sync_api import sync_playwright  # noqa: E402

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(("  [PASS] " if cond else "  [FAIL] ") + name + (("  -- " + detail) if (detail and not cond) else ""))


def shot(page, name):
    page.screenshot(path=str(SHOTS / name), full_page=False)
    print("  [SHOT] " + name)


def run():
    index_url = (ROOT / "index.html").resolve().as_uri()
    tests_url = (ROOT / "tests" / "tests.html").resolve().as_uri()

    with sync_playwright() as p:
        browser = p.chromium.launch()

        # ============ 1. 自动测试页 ============
        print("\n== tests/tests.html 自动测试 ==")
        page = browser.new_page(viewport={"width": 1440, "height": 1024})
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.goto(tests_url)
        page.wait_for_function(
            "() => document.getElementById('summary') && !document.getElementById('summary').textContent.includes('运行中')",
            timeout=15000,
        )
        summary = page.inner_text("#summary")
        print("  " + summary)
        check("自动测试全部通过", "失败 0" in summary, summary)
        fail_items = page.eval_on_selector_all(
            ".result-item", "els => els.filter(e => e.querySelector('.result-fail')).map(e => e.innerText)"
        )
        for it in fail_items:
            print("    FAIL DETAIL: " + it.replace("\n", " | "))
        shot(page, "tests-page.png")
        check("测试页无 JS 运行时错误", not errors, "; ".join(errors[:3]))
        page.close()

        # ============ 2. 主页面（1440×1024） ============
        print("\n== index.html 主流程（1440×1024） ==")
        ctx = browser.new_context(viewport={"width": 1440, "height": 1024})
        page = ctx.new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.goto(index_url)

        # 默认团队空间首页
        page.wait_for_selector(".nav-item[data-project-id]")
        labels = page.eval_on_selector_all(".nav-item[data-project-id] .nav-label", "els => els.map(e => e.textContent)")
        check("默认团队空间显示团队项目", labels == ["Aurora Skincare", "TrailBrew Outdoor"], str(labels))
        recents = page.eval_on_selector_all(".nav-item--recent .nav-title", "els => els.map(e => e.textContent)")
        check("默认团队空间显示团队最近会话", recents == ["Aurora Skincare", "TrailBrew Outdoor"], str(recents))
        entry = page.inner_text("#sidebar-account")
        check("账户入口显示账号名与团队空间", "林小满" in entry and "Northstar Studio" in entry, entry.replace("\n", " / "))
        check("顶栏为新会话状态", "新会话" in page.inner_text("#topbar"))
        shot(page, "home-team-default-1440.png")

        # 账户浮窗：创建者默认态
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.wait_for_timeout(250)  # 等待入场动画结束
        pop_text = page.inner_text(".account-popover")
        for t in ["林小满", "xiaoman.lin@example.com", "Northstar Studio", "团队空间", "创建者",
                  "用量与计费", "团队管理", "业务邮箱", "通知", "个人设置", "退出登录"]:
            check("浮窗包含「%s」" % t, t in pop_text)
        check("浮窗不含「开启团队协作」", "开启团队协作" not in pop_text)
        check("浮窗未读徽标为 3", page.inner_text(".badge-unread").strip() == "3")
        check("浮窗总宽度 280（含边框）", abs(page.eval_on_selector(".account-popover", "e => e.getBoundingClientRect().width") - 280) < 0.01)
        shot(page, "popover-team-creator.png")

        # 切换按钮悬停提示（默认不显示，悬停才显示）
        check("悬停前提示不显示", not page.is_visible(".switch-hint"))
        page.hover(".switch-btn")
        page.wait_for_timeout(100)
        check("悬停后显示「切换空间」提示", page.is_visible(".switch-hint"))
        shot(page, "popover-switch-hover.png")

        # 在团队空白会话输入未发送内容（先关闭浮窗）
        page.click("#account-entry")  # 关闭浮窗
        page.wait_for_timeout(100)
        check("浮窗已关闭", page.locator(".account-popover").count() == 0)
        page.fill(".composer textarea", "团队空间的未发送输入ABC123")

        # Esc 关闭浮窗
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.keyboard.press("Escape")
        page.wait_for_timeout(100)
        check("Esc 关闭浮窗", page.locator(".account-popover").count() == 0)

        # 点击外部关闭浮窗
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.click(".blank-title")
        page.wait_for_timeout(100)
        check("点击外部关闭浮窗", page.locator(".account-popover").count() == 0)

        # 输入内容仍保留（浮窗开关不影响）
        check("浮窗开关后输入保留", page.input_value(".composer textarea") == "团队空间的未发送输入ABC123")

        # 直接切换到个人空间：点击切换按钮即刻切换，无选择列表
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.click(".switch-btn")
        page.wait_for_function(
            "() => [...document.querySelectorAll('.nav-item[data-project-id] .nav-label')].map(e=>e.textContent).join(',') === 'PetPal Essentials,HomeCafe Lab'",
            timeout=5000,
        )
        check("切换后显示个人空间项目", True)
        recents = page.eval_on_selector_all(".nav-item--recent .nav-title", "els => els.map(e => e.textContent)")
        check("切换后显示个人空间最近会话", recents == ["PetPal Essentials", "HomeCafe Lab"], str(recents))
        entry = page.inner_text("#sidebar-account")
        check("个人空间账户入口：账号不变、空间为个人空间", "林小满" in entry and "个人空间" in entry and "Northstar" not in entry, entry.replace("\n", " / "))
        check("切换后浮窗关闭", page.locator(".account-popover").count() == 0)
        check("首次进入个人空间为空白会话", "新会话" in page.inner_text("#topbar") and page.input_value(".composer textarea") == "")
        shot(page, "home-personal-1440.png")

        # 个人空间浮窗：无团队管理
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.wait_for_timeout(250)  # 等待入场动画结束
        pop_text = page.inner_text(".account-popover")
        check("个人空间浮窗无团队管理", "团队管理" not in pop_text)
        check("个人空间浮窗无开启团队协作", "开启团队协作" not in pop_text)
        check("个人空间浮窗无创建者身份", "创建者" not in pop_text)
        check("个人空间浮窗有切换按钮", page.locator(".switch-btn").count() == 1)
        check("个人空间浮窗账号信息一致", "林小满" in pop_text and "xiaoman.lin@example.com" in pop_text)
        shot(page, "popover-personal.png")

        # 在个人空间打开最近会话，输入草稿，切回团队再切回，验证恢复
        page.click("#account-entry")  # 关闭浮窗
        page.wait_for_timeout(100)
        page.click(".nav-item[data-conv-id='conv-personal-homecafe']")
        page.wait_for_selector(".msg-bubble--user")
        check("打开会话显示历史消息", "磨豆机" in page.inner_text(".chat-scroll"))
        check("会话视图顶栏仅显示一次项目名称", page.inner_text("#topbar").count("HomeCafe Lab") == 1 and "关联项目：" not in page.inner_text("#topbar"))
        page.fill(".composer textarea", "个人空间的会话草稿XYZ789")
        shot(page, "conversation-open.png")

        # 切回团队（直接切换）
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.click(".switch-btn")
        page.wait_for_function(
            "() => [...document.querySelectorAll('.nav-item[data-project-id] .nav-label')].map(e=>e.textContent).join(',') === 'Aurora Skincare,TrailBrew Outdoor'",
            timeout=5000,
        )
        check("切回团队空间项目正确", True)
        # 团队空白会话草稿恢复
        check("团队空白会话草稿恢复", page.input_value(".composer textarea") == "团队空间的未发送输入ABC123",
              page.input_value(".composer textarea"))

        # 再次切到个人空间（直接切换），验证会话位置与草稿恢复
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.click(".switch-btn")
        page.wait_for_function(
            "() => document.querySelector('.composer textarea') && document.querySelector('.composer textarea').value === '个人空间的会话草稿XYZ789'",
            timeout=5000,
        )
        check("再次进入个人空间恢复会话位置与草稿", True)
        check("会话历史仍在", page.locator(".msg-bubble--user").count() >= 1)

        # 刷新页面，验证草稿持久化
        page.reload()
        page.wait_for_selector(".composer textarea")
        check("刷新后会话位置恢复", page.locator(".msg-bubble--user").count() >= 1)
        check("刷新后草稿恢复", page.input_value(".composer textarea") == "个人空间的会话草稿XYZ789",
              page.input_value(".composer textarea"))

        # ---- 切换中锁定与「切换中…」反馈（通过测试注入口注入 800ms 慢传输） ----
        page.evaluate("() => window.__creatorScoutStore.__setTransport((t, seq) => new Promise(res => setTimeout(() => res({spaceId: t, seq}), 800)))")
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.click(".switch-btn")
        page.wait_for_timeout(200)
        check("切换中提示显示「切换中…」", "切换中" in page.inner_text(".switch-hint"))
        check("切换中提示常显（不依赖悬停）", page.is_visible(".switch-hint.is-busy"))
        check("切换中切换按钮被锁定", page.locator(".switch-btn[disabled]").count() == 1)
        check("切换中菜单项被锁定", page.locator(".pop-menu-item").count() > 0 and page.locator(".pop-menu-item[disabled]").count() == page.locator(".pop-menu-item").count())
        # 切换中再次点击账户入口不响应（锁定重复操作）
        page.click("#account-entry", force=True)
        page.wait_for_timeout(100)
        check("切换中账户入口不重复打开/关闭浮窗", page.locator(".account-popover").count() == 1)
        page.wait_for_function(
            "() => [...document.querySelectorAll('.nav-item[data-project-id] .nav-label')].map(e=>e.textContent).join(',') === 'Aurora Skincare,TrailBrew Outdoor'",
            timeout=5000,
        )
        check("慢传输切换最终成功", True)
        page.evaluate("() => window.__creatorScoutStore.__resetTransport()")

        # ---- 切换失败：保留原空间与输入，toast 提供重试 ----
        page.evaluate("() => window.__creatorScoutStore.__setTransport(() => Promise.reject(new Error('模拟失败')))")
        page.fill(".composer textarea", "失败场景下不能丢的输入")
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.click(".switch-btn")
        page.wait_for_selector(".toast")
        toast_text = page.inner_text(".toast")
        check("失败提示保留原空间与输入", "切换空间失败" in toast_text and "保留" in toast_text, toast_text)
        check("失败后仍在团队空间", page.eval_on_selector_all(".nav-item[data-project-id] .nav-label", "els => els.map(e => e.textContent)")[0] == "Aurora Skincare")
        check("失败后输入保留", page.input_value(".composer textarea") == "失败场景下不能丢的输入")
        page.wait_for_timeout(200)
        check("失败后浮窗仍打开（可重试）", page.locator(".account-popover").count() == 1)
        # 点击 toast 的「重试」：恢复传输后切换成功
        page.evaluate("() => window.__creatorScoutStore.__resetTransport()")
        page.click(".toast-action")
        page.wait_for_function(
            "() => [...document.querySelectorAll('.nav-item[data-project-id] .nav-label')].map(e=>e.textContent).join(',') === 'PetPal Essentials,HomeCafe Lab'",
            timeout=5000,
        )
        check("toast 重试后切换成功", True)
        # 重试前在团队空间（空白会话输入“失败场景下不能丢的输入”），重试目标为个人空间：
        # 目标空间恢复自己的会话位置与草稿；原空间输入按空间隔离保留
        check("重试后恢复目标空间（个人）自己的会话草稿", page.input_value(".composer textarea") == "个人空间的会话草稿XYZ789",
              page.input_value(".composer textarea"))
        check("重试后原空间（团队）输入按空间隔离保留",
              page.evaluate("() => window.__creatorScoutStore.getDraft('sp-team-northstar', '__blank__')") == "失败场景下不能丢的输入")
        # 切回团队，恢复演示默认态（直接切换）
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.click(".switch-btn")
        page.wait_for_function(
            "() => [...document.querySelectorAll('.nav-item[data-project-id] .nav-label')].map(e=>e.textContent).join(',') === 'Aurora Skincare,TrailBrew Outdoor'",
            timeout=5000,
        )

        # 未接入功能提示（不跳转、不伪造成功）—— 此时处于团队空间
        page.click(".nav-item[data-project-id='proj-team-aurora']")
        page.wait_for_selector(".toast")
        check("项目入口提示未开放", "项目工作区暂未开放" in page.inner_text(".toast"))
        page.wait_for_timeout(4000)

        # 发送按钮（有内容时提示暂未开放并保留输入）
        page.fill(".composer textarea", "尝试发送的内容")
        page.click(".btn-send")
        page.wait_for_selector(".toast")
        check("发送提示暂未开放", "暂未开放" in page.inner_text(".toast") and "保留" in page.inner_text(".toast"))
        check("发送提示后输入保留", page.input_value(".composer textarea") == "尝试发送的内容")
        page.wait_for_timeout(4200)  # 等上一条 toast 自动消失，避免读到旧提示

        # TikTok 入口
        page.click(".nav-item[data-platform='tiktok']")
        page.wait_for_selector(".toast")
        check("TikTok 提示未开放", "该功能暂未开放" in page.inner_text(".toast"))

        # 退出登录：取消不改状态
        page.wait_for_timeout(4000)
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.click(".pop-menu-item--logout")
        page.wait_for_selector(".modal")
        check("退出登录有二次确认", "退出登录" in page.inner_text(".modal"))
        shot(page, "logout-confirm.png")
        page.click("[data-modal='cancel']")
        page.wait_for_timeout(200)
        check("取消退出后保持登录状态", page.locator("#app").is_visible() and page.locator(".modal").count() == 0)
        check("取消退出后输入仍在", page.input_value(".composer textarea") == "尝试发送的内容")

        # 确认退出 → 已退出页 → 重新进入
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.click(".pop-menu-item--logout")
        page.wait_for_selector(".modal")
        page.click("[data-modal='confirm']")
        page.wait_for_selector("#signed-out:not([hidden])")
        check("确认退出显示已退出页", "已退出本地演示登录" in page.inner_text("#signed-out"))
        check("退出说明不宣称真实注销", "不代表已注销任何真实服务会话" in page.inner_text("#signed-out"))
        page.click("#reenter-btn")
        page.wait_for_selector("#app:not([hidden])")
        check("重新进入恢复应用", page.locator("#app").is_visible())
        check("重新进入后数据仍在", page.input_value(".composer textarea") == "尝试发送的内容",
              page.input_value(".composer textarea"))
        # 清理演示状态（避免影响后续人工验收的默认态）
        page.evaluate("() => localStorage.removeItem('creator_scout_home_v1')")
        page.close()
        ctx.close()
        check("主页面无 JS 运行时错误", not errors, "; ".join(errors[:3]))

        # ============ 3. 1280×800 适配 ============
        print("\n== 1280×800 适配 ==")
        ctx2 = browser.new_context(viewport={"width": 1280, "height": 800})
        page = ctx2.new_page()
        errors2 = []
        page.on("pageerror", lambda e: errors2.append(str(e)))
        page.goto(index_url)
        page.wait_for_selector(".nav-item[data-project-id]")
        page.click("#account-entry")
        page.wait_for_selector(".account-popover")
        page.wait_for_timeout(250)
        box = page.eval_on_selector(".account-popover", "e => { const r = e.getBoundingClientRect(); return {top: r.top, left: r.left, bottom: r.bottom, right: r.right}; }")
        check("1280×800 浮窗不出屏（上）", box["top"] >= 0, str(box))
        check("1280×800 浮窗不出屏（左）", box["left"] >= 0)
        check("1280×800 浮窗不出屏（下）", box["bottom"] <= 800)
        check("1280×800 浮窗不出屏（右）", box["right"] <= 1280)
        shot(page, "home-team-1280-popover.png")
        # 本轮已删除三栏提示与底部说明，检查真实输入区与操作行。
        visible = page.eval_on_selector(".composer", "e => { const r = e.getBoundingClientRect(); return r.bottom <= 800 && r.top >= 0 && r.right <= 1280; }")
        check("1280×800 输入区及操作行不出屏", visible)
        page.evaluate("() => localStorage.removeItem('creator_scout_home_v1')")
        check("1280×800 无 JS 运行时错误", not errors2, "; ".join(errors2[:3]))
        page.close()
        ctx2.close()

        browser.close()

    print("\n================ 结果汇总 ================")
    print("通过: %d  失败: %d" % (len(PASS), len(FAIL)))
    if FAIL:
        print("失败项:")
        for f in FAIL:
            print("  - " + f)
        sys.exit(1)
    print("全部通过 ✅")


if __name__ == "__main__":
    try:
        run()
    except Exception:
        traceback.print_exc()
        sys.exit(2)
