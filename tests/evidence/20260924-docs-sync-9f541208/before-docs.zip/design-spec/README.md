# KOL Collect 设计规范与双 Agent 协作
更新：2026-09-22

## 分工
- ChatGPT Work：产品负责人、UI 设计协作者、Figma 读取与规范整理、工程任务拆解、最终视觉验收。
- Claude Desktop + GLM = 用户所称“代码 task”；是同一个执行方，不是第三个 Agent。负责代码实现、运行、测试、Bug 修复。
- 两个客户端共用本工作区。交接优先落到 design-spec/ 与 tasks/，聊天仅用于索引和沟通。
- 默认不由 ChatGPT Work 大范围修改业务代码；本轮只新增规范、证据和任务文件。

## 权威与流程
已确认 Figma → 本目录结构化规范 → tasks/ Patch Task → GLM 实现与截图 → ChatGPT Work 验收 → 必要的新 Patch Task。
视觉以对应 Figma Frame、Component、Variables 为准；产品行为以用户已确认要求为准。发现冲突必须明确记录，不凭截图推断新的产品规则。
历史交接用于背景；同一范围的最新明确要求优先。截图辅助核对，不取代结构数据。
GLM 不自行重新设计、美化或简化，不重构无关代码、不更换技术栈。

## 当前入口

- [Creator Scout 品牌规范 · Discovery](foundations/creator-scout-brand.md)：已选定标识的名称、版本、色彩、字体、留白、最小尺寸与导出要求。
- [后台通用 UI 规则](foundations/backend-ui-rules.md)：后续页面默认沿用的 Mint、文字层级、模块边界、来源行和数据口径规则。
- [Instagram 达人营销入口设计规范](pages/instagram-agent-entry.md)：记录 00–11 项目创建与首次任务流程，以及 100／50 位预览分支、V9 配置继承和任务成功后的会话边界；产品与工程执行以[登录首页统一需求规格](../需求说明/登录首页_统一需求规格.md)为准。
- [账户中心设计规范](pages/account-center.md)：个人／团队空间、权益、团队协作、成员、邀请和业务邮箱占位的首轮 Figma 规范。
- [V9 确认基线](../V9_BASELINE.md)：新建 Agent 已定版；后续进入 [V10](../AGENT_V10_HANDOFF.md)。
- [最终收尾验收](../tasks/2026-09-21_new-agent-task-error-feedback-acceptance.md)
- [新建 Agent 任务规范](pages/new-agent-task.md)
- [设计 Tokens](design-tokens.md)
- [组件映射与状态](components/new-agent-task-controls.md)
- [已完成的三区 Patch（历史）](../tasks/2026-09-20_new-agent-task-three-areas-patch.md)；当前无待执行 V9 Patch。
- 三区及后续八轮细节、逻辑修复、失败提示收尾已完成。旧整窗未执行项不自动转入 V10。主文件与页面规范顶部的定版补充共同记录已批准偏差，禁止按旧目标回滚。
- evidence/：2026-09-20 实际读取的 Figma 结构与设计上下文；生成代码是参考，不是可直接粘贴的生产实现。

## 维护规则
后续页面先引用 `foundations/backend-ui-rules.md`，再记录页面自己的结构、具体值和覆盖项。通用规则不自动触发已冻结页面返工。
每次开工先读当前文件，记录 SHA256 与检查日期。任务中的旧值只对该快照有效；已修好的项目不重复覆盖。
每份规范记录目标、Frame、结构、尺寸、间距、字体、颜色、边框、组件、交互、数据状态、响应式、产品不变量、已知差异。
任务状态：待实现 → 待验收 → 通过 / 需 Patch。不得把文件已创建或功能测试通过标为视觉验收通过。
验收核对布局、比例、间距、字体、组件、颜色、边框圆角、对齐、状态和原交互；记录运行环境、截图和未通过项。
当前工作区存在 .git 条目，但本次 git status 返回“not a git repository”；未建立或假定可用 Git 分支。GLM 使用独立备份保护现场。

## 数据接入与历史差异
最新页面规范已确认05C/05D/05E只读全量名单及人工品牌两字段方案，覆盖早期逐账号排除和补充原因选填描述；已纳入 V9 基线，并兼容历史数据。当前真实名单数据接入缺口和冻结外层尺寸造成的差异须如实记录。
