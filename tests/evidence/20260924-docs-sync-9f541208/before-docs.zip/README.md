# KOL Collect

KOL Collect 面向出海 KOL 营销团队，覆盖客户项目、达人发现与采集、资料补全及后续运营。本工作区当前用于产品需求、交互原型、设计规范与工程交接。

## 当前确认版本：V9

更新日期：2026-09-21。负责人已确认新建 Agent 任务优化完成，以当前 V9 为基准。后续功能优化进入 V10；V9 保留不覆盖。

- [V9 当前原型](./智能挖掘_任务详情_v9_demo.html)
- [V9 确认基线与指纹](./V9_BASELINE.md)：确认范围、权威顺序、已关闭任务和验证边界。
- [最终收尾验收](./tasks/2026-09-21_new-agent-task-error-feedback-acceptance.md)
- [V10 后续交接](./AGENT_V10_HANDOFF.md)：已提出画像摘要取舍、停止任务两项需求，方案待讨论，未创建 V10 原型。

本次确认的是新建 Agent 任务及其修复收尾；不代表全项目或真实 AI、采集、数据库已接入并验收。

## 设计与开发协作

- [设计规范入口](./design-spec/README.md)与[新建 Agent 任务规范](./design-spec/pages/new-agent-task.md)
- [工程任务索引](./tasks/README.md)：旧 V9 任务已关闭或被替代，不再作为待执行清单。
- ChatGPT Work 负责产品、设计读取、规范、任务拆解及验收；Claude Desktop + GLM（代码 task）负责实现与测试。交接优先写入本工作区。

## 项目背景与历史资料

- [项目概览](./PROJECT_OVERVIEW.md)、[现有管理台结构](./KOL-Collect管理台结构与功能文档.md)：系统背景，不自动构成新开发范围。
- [V9 原始整合交接](./AGENT_V9_HANDOFF.md)：历史整合要求；其中从 V8 生成 V9 的步骤已过时，不再执行。
- [V8 全页面需求](./需求说明/KOLCollect_全页面产品需求说明_V8.md)：继承业务规则的历史参考；冲突以 V9 确认记录和最新要求为准。
- [V8 交接](./AGENT_V8_HANDOFF.md)、[V5/V7 历史交接](./AGENT_V5_HANDOFF.md)、[早期产品讨论](./AGENT_PRODUCT_BASELINE.md)保留追溯，不作为当前版本入口。

历史 HTML 和独立体验稿保留对照，不从其未采纳功能推导新增任务。
