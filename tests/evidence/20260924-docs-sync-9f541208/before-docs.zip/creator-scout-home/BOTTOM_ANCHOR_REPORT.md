# Creator Scout 浮窗底边贴合与高度过渡报告

日期：2026-09-24。范围仅为 `creator-scout-home/` 账户浮窗定位及高度过渡。264px宽度、字号、颜色、图标与内部间距保持已验收版本；不改或合并V9，不接入真实服务，不继续首页Figma视觉同步。

## 1. 实现结果

移除打开时测量个人／团队最大高度并固定顶部的定位逻辑。浮窗改为依附当前账户入口，底边位于入口上方8px；个人空间不再产生原先46px的外部间隙，也不在内部填充隐藏菜单占位。

| 正常桌面状态 | 外框宽×高（含边框） | 与账户入口间距 |
|---|---|---|
| 团队创建者 | 264×389px | 8px |
| 切到个人空间 | 264×351px | 8px |
| 再切回团队 | 264×389px | 8px |

空间成功改变后，保留同一个浮窗、账号区及切换按钮，原位更新相关菜单。采用150ms缓出高度插值；底边固定，上边缘与按钮随高度移动38px，不缩放任何文字或图标。动画结束恢复自然高度及原滚动样式，不残留固定高度。原有入场动画不因空间切换重新播放。

这次明确放弃“按钮屏幕坐标绝对固定”，优先保证浮窗与账户入口的贴合关系。后台依旧在切换中／失败时不重绘，成功后各相关区域更新一次。

## 2. 边界及交互保护

切换成功仍不自动关闭浮窗；Esc、外部点击或账户入口可主动关闭，结果回调不重开或抢焦点。键盘焦点保留在同一个切换按钮，继续Tab时直接完成短过渡，避免落入暂时裁切的菜单。

动画每帧更新外置切换提示的位置，避免提示停留在旧按钮位置。窗口变化、关闭或退出时取消动画并清理临时样式；过渡中反向切换可以衔接当前高度，不遗留旧动画。

减少动态效果模式跳过高度过渡；已经限高滚动的小窗口也不强做高度动画，优先保证菜单可达。保留现有空间隔离、草稿、新会话、长输入、失败重试及退出确认行为。

## 3. 修改文件

运行代码只改 `js/app.js`：底部定位、150ms高度过渡及取消／清理机制。`css/styles.css`、`js/ui.js`、`js/store.js`、`js/fixtures.js`、`index.html`、Logo、favicon和V9均与本轮开工备份一致。

测试：更新 `tests/verify-switch-continuity.py` 中已被最新要求替代的顶部固定断言；新增 `tests/verify-bottom-anchor.py`。文档更新 `README.md`、历史 `SWITCH_CONTINUITY_REPORT.md` 的替代说明及本报告。

## 4. 验证

Windows本地隔离Chromium，覆盖1440×1024、1280×800，以及320×420、280×240小窗口。

- `verify-bottom-anchor.py`：416项通过，0失败。包含逐帧几何采样、双向伸缩、中间高度和单向收放、所有采样帧底部8px、提示跟随、焦点、动画中关闭／调整窗口／Tab／反向切换／减少动态效果，以及继承的连续性、尺寸、长文案、草稿和输入回归。
- `verify.py` 主流程复跑：76项通过，0失败；调用的浏览器内逻辑测试24项通过。各层有重叠，不累计成独立场景数。
- 两组检查未发现JavaScript运行时错误；测试结果绑定的运行文件哈希与交付代码一致。

当前 `js/app.js` SHA256：`81baae370f337cb7a8bbbf1b3427e3796019b2b349e3a7f8802bc4a881253523`。

## 5. 入口与证据

运行入口：`E:\codex\KOL collect\creator-scout-home\index.html`，可直接打开。

复跑：在 `creator-scout-home/` 内执行 `python -X utf8 tests/verify-bottom-anchor.py` 或 `python -X utf8 tests/verify.py`。

截图目录：`screenshots/20260924-bottom-anchor/`。`personal-1440-gap8.png`、`personal-1280-gap8.png` 为修复后的个人空间，`team-1440-gap8.png`、`team-return-1440-gap8.png` 为团队及切回团队。`small-*.png` 为小窗口；子目录保留各层回归截图。

证据目录：`tests/evidence/20260924-bottom-anchor/`，包括 `before-source.zip`、`protected-sha.json`、逐帧及断言结果 `bottom-anchor-results.json`、`main-regression-output.txt`、`main-regression-results.json`。Git不可用，采用开工备份、SHA及差异复核，未进行Git提交。

本轮未发现阻塞项；实际使用手感仍由负责人验收。最新Figma首页视觉还原、真实浏览器标签栏favicon专项及真实服务不在本轮范围，未宣称完成。
